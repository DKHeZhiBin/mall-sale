"""MindBridge engineering harness package."""

